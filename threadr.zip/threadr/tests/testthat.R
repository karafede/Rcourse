library(testthat)
library(threadr)

test_check("threadr")


